$(document).ready(function() {
     $('#tipue_search_input').tipuesearch();
     
});
