<?php

class auto
{
  public $prop1 = "";

  public function setProperty($newval)
  {
      $this->prop1 = $newval;
  }

  public function getProperty()
  {
      return $this->prop1 . "<br />";
  }
}




//attributes van een blog.
//methods zijn de functies.

//DESTRUCTOR==KAPOT===died();

class Blog{

}


?>
